Keccak Code Package
===================

The files in kcp are taken from the Keccak Code Package. They have been
slightly to be C89 compatible. The architecture specific header file
KeccakP-1600-SnP.h ha been renamed to KeccakP-1600-SnP-opt32.h or
KeccakP-1600-SnP-opt64.h.

The 64bit files were generated with generic64lc/libkeccak.a.pack target, the
32bit files with generic32lc/libkeccak.a.pack.

